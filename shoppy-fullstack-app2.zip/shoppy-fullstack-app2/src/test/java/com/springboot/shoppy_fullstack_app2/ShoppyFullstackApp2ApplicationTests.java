package com.springboot.shoppy_fullstack_app2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppyFullstackApp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
